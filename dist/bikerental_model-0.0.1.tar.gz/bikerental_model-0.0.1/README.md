# Creating venv with name 'bikemodel'
python -m venv bikemodel

# activating the venv:
source bikemodel/bin/activate 
